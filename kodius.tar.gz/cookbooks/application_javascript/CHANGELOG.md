# Application_Javascript Changelog

## v1.0.0

Initial release!
